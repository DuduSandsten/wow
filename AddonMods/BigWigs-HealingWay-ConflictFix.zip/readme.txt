2015-11-11

BigWigs_RespawnTimers: 

1.
Fixed a small bug with addons conflicting due to faulty icon translation in libs\Babble-Spell-2.2
["Healing Way"] = "Spell_Nature_HealingWay",

2.
Also added hidden command /bigwigsclickthrough
To toggle mouse clickhrough for respawn timers.

Best Regards
http://nirklars.wordpress.com/wow