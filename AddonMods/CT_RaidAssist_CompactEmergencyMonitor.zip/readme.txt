Minor edit to make emergency monitor more compact

See attached images on how to edit and customize yourself :)

To test/preview how they look after editing type this command into chat to force show them:
/run for i=1,5 do CT_RA_EmergencyFrame["frame"..i]:Show() end

You will get lua errors if you hover over it in this mode. Use /reloadui to fix !

Best Regards
http://nirklars.wordpress.com/wow