Guild Roster Backup

I wrote this addon for Vanilla WoW in order to make quick 
and simple backups of our guild roster. It creates a simple 
html table listing all players in the guild along with rank, 
notes and officer notes.

It does this by generating a one line html page that you can
copy and paste into a text editor. Might require WoWAce 
library to be enabled to work, I forgot. It�s included in 
most other addons though.

Instructions:
1.  Type /gr or /guildroster with the addon installed to get
    a text dialog box with an OK button.
2.  Press CONTROL+C in order to copy the text.
3.  Open any basic plain text editor like notepad, notepad2 
    or notepad++ and paste the text in that.
4.  Save the file as anything.html
5.  Open the file in any web browser of choice.


Feature added in Version 2:
Creates list with amount of all items in bags and your bank by
typing /gb /guildbank or /itemlist
You need to keep the bank open in order to get the contents 
from the bank. If not it will show a blue warning message.


Written by Sandsten on Kronos
https://nirklars.wordpress.com/wow/addon-guildroster-to-html/