--requires wowace
SLASH_GUILDROSTER1, SLASH_GUILDROSTER2 = "/gr", "/guildroster"
function SlashCmdList.GUILDROSTER(msg, editbox)
	numberOfMembers = GetNumGuildMembers(true);
	
	--table formatting
	output = "<style>table{font-family: arial;}</style><table><tr><td><strong>Name</strong></td><td><strong>Rank</strong></td><td><strong>Class</strong></td><td><strong>Level</strong></td><td><strong>Note</strong></td><td><strong>Officer note</strong></td></tr>";
	
	--go through every member in the guild
	for i = 1, numberOfMembers do
		name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName = GetGuildRosterInfo(i);

		output =  output .. "<tr><td>" .. name .. "</td><td>" .. rank .. "</td><td>" .. class .. "</td><td>" .. level .. "</td><td>".. note .. "</td><td>".. officernote .. "</td><td></tr>";
	end
	
	output = output .. "</table>";
	
	--show message box to copy and paste from
	StaticPopupDialogs["COPYTEXT"] = {
		text = "Copy and paste the text below and paste into a text editor, then save as anything.html and open in a browser.",
	  	button1 = "OK",
		
		OnShow = function()
			getglobal(this:GetName().."EditBox"):SetFocus()
			getglobal(this:GetName().."EditBox"):SetText(output)
			getglobal(this:GetName().."EditBox"):HighlightText()
		end,
		
	  	timeout = 0,
	  	hasEditBox = true,
	  	whileDead = true,
	  	hideOnEscape = true,
	  	preferredIndex = 3,  -- avoid some UI taint, see http://www.wowace.com/announcements/how-to-avoid-some-ui-taint/
	}
	StaticPopup_Show ("COPYTEXT")
end
