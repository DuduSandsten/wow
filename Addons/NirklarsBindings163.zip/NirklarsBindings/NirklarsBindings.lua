----------------------
-- NirklarsBindings --
----------------------

-- Localisation stuff

BINDING_HEADER_NIRKLARSBINDINGS_HOSTILE = "Nirklars Druid Bindings - Hostile"
BINDING_HEADER_NIRKLARSBINDINGS_MOUSEOVERHEALING = "Nirklars Druid Bindings - Mouseover Healing"
BINDING_HEADER_NIRKLARSBINDINGS_BUFFS = "Nirklars Druid Bindings - Buffs"
BINDING_HEADER_NIRKLARSBINDINGS_MOUSEOVERBUFFS = "Nirklars Druid Bindings - Mouseover Buffs"
BINDING_HEADER_NIRKLARSBINDINGS_AUTOSELFCAST = "Nirklars Druid Bindings - Auto self cast"
BINDING_HEADER_NIRKLARSBINDINGS_SPAMMABLE = "Nirklars Druid Bindings - Spammable"
BINDING_HEADER_NIRKLARSBINDINGS_SPECIAL = "Nirklars Druid Bindings - Special"
BINDING_HEADER_NIRKLARSBINDINGS = "Nirklars Druid Bindings - General"
BINDING_HEADER_NIRKLARSBINDINGS_ALLCLASSES = "Nirklars Bindings - All classes"

SlashCmdList["SLASH_NIRKLARS"] = function(Flag) end
SlashCmdList["SLASH_AUTOTARGET"] = function(Flag) end
SlashCmdList["SLASH_AUTOSELFCAST"] = function(Flag) end
SlashCmdList["SLASH_USEACTIONBAR"] = function(Flag) end
SlashCmdList["SLASH_USEACTIONBARATTACK"] = function(Flag) end
SlashCmdList["SLASH_MOUSEOVERCAST"] = function(Flag) end
SlashCmdList["SLASH_MOUSEOVERCASTWARNING"] = function(Flag) end
SlashCmdList["SLASH_WARNINGCHANNEL"] = function(Flag) end
SlashCmdList["SLASH_CANCELFORM"] = function(Flag) end
SlashCmdList["SLASH_CATFORMSTEALTH"] = function(Flag) end
SlashCmdList["SLASH_FAERIEFIREANY"] = function(Flag) end
SlashCmdList["SLASH_BEARFORMCHARGE"] = function(Flag) end
SlashCmdList["SLASH_BEARFORMBASH"] = function(Flag) end
SlashCmdList["SLASH_TRAVELFORM"] = function(Flag) end
SlashCmdList["SLASH_AQUATICFORM"] = function(Flag) end
SlashCmdList["SLASH_OMENTRACKCOMBO"] = function(Flag) end
SlashCmdList["SLASH_MOTWSPAM"] = function(Flag) end
SlashCmdList["SLASH_THORNSSPAM"] = function(Flag) end
SlashCmdList["SLASH_MOTWCHECK"] = function(Flag) end
SlashCmdList["SLASH_BUFFCHECK"] = function(Flag) end
SlashCmdList["SLASH_INNERVATE"] = function(Flag) end
SlashCmdList["SLASH_TIGERF"] = function(Flag) end
SlashCmdList["SLASH_ENRAGE"] = function(Flag) end
SlashCmdList["SLASH_REJUVOVER"] = function(Flag) end
SlashCmdList["SLASH_BUFFS"] = function(Flag) end
SlashCmdList["SLASH_DEBUFFS"] = function(Flag) end
SlashCmdList["SLASH_CANCELBUFF"] = function(Flag) end
SlashCmdList["SLASH_USE"] = function(Flag) end
SlashCmdList["SLASH_MODECURSE"] = function(Flag) end
SlashCmdList["SLASH_NIRKNOTICE"] = function(Flag) end

--info
SLASH_NIRKLARS1, SLASH_NIRKLARS2, SLASH_NIRKLARS3 = "/nirk", "/nirklars", "/bindings"
function SlashCmdList.NIRKLARS(msg, editbox)
	Print("<< Nirklars Keybindings V1.62 - commands >> nirklars.wordpress.com/wow/")
	Print("/asc /autoselfcast <spellname> - self cast with autoselfcast disabled")
	Print("/att /autotarget - target nearest hostile if no current target")
	Print("/usa /useactionbar <id> - use action bar (useful for autoattack spell)")
	Print("/usat /useactionbarattack <id> - combines both above")
	Print("/mc /mouseovercast <spellname> - mouseover cast, works with raidframes")
	Print("/mcw /mouseovercastwarn <spellname> - mouseover cast with warning '/w'")
	Print("/warnc /warningchannel <channel> - save warning channel example: '/warnc guildhealers'")
	Print("/ccf /cancelform - cancel any shapeshifting")
	--Print("/catf /catform - enter catform and stealth, spammable")
	--Print("/bearf /bearform - enter bearform and feral charge, spammable")
	--Print("/bearfb /bearformb - enter bearform and bash, spammable")
	--Print("/travelf /travelform - enter travelform, spammable")
	--Print("/aquaf /aquaticform - enter aquatic form, spammable")
	Print("/faeriefireany /faeriefire - chooses feral or regular depending on shapeshift")
	Print("/enrage /druidenrage - click once to use enrage, twice to cancel")
	Print("/innervate - mouseover support, range check, overwrite prevention and warning message")
	Print("/tigerf /tigersfury - spammable tigers fury, wont overwrite")
	Print("/omencombo - Omen of Clarity/TrackHumanoids/Enrage all in one")
	Print("/use /useitem - use an item in bag, example: '/use Brown Kodo'")
	Print("/debuffs - lists all debuffs (as interface names) on current target")
	Print("/buffs - lists all buffs (as interface names) on current target")
	Print("/cbf /cancelbuff <buff interface name> - cancel a buff by part of name")
	Print("/check /buffcheck <buffname> - list party/raid members lacking specified buff")
	Print("/motwbuff /motwspam - target nearest friend and buff if unbuffed, spammable")
	Print("/thornsbuff /thornsspam - target nearest friend and buff if unbuffed, spammable")
	Print("/rejuvoverwrite /rejuv - toggle rejuvenation overwrite/swiftmend if active")
	Print("/nirknotice /castingfeedback - toggle message on/off when casting mouseover")
	Print("/modecurse - mouseover remove curse/poison/magic/disease")
end

function Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage(tostring(msg),0.4,1,1, 3)
end

function PrintWarning(msg)
	UIErrorsFrame:AddMessage(msg, 1.0, 1.0, 0.0, 3)
end

function CastNotice(spellname,target)
	--if not success then
	--	if target == nil then
	--		--DEFAULT_CHAT_FRAME:AddMessage("Casting "..(tostring(msg)),0.2,0.2,1)
	--		message = tostring(spellname).." failed!"
	--	else
	--		--DEFAULT_CHAT_FRAME:AddMessage("Casting "..(tostring(msg).." on "..tostring(target)),0.2,0.2,1)
	--		message = tostring(spellname).." failed "..tostring(target).." is out of range!"
	--	end
	--	UIErrorsFrame:AddMessage(message, 1.0, 0.0, 0.0, 3)
	--else
		if target == nil then
			--DEFAULT_CHAT_FRAME:AddMessage("Casting "..(tostring(msg)),0.2,0.2,1)
			message = "Casting "..tostring(spellname)
		else
			--DEFAULT_CHAT_FRAME:AddMessage("Casting "..(tostring(msg).." on "..tostring(target)),0.2,0.2,1)
			message = "Casting "..tostring(spellname).." on "..tostring(target)
		end
		
		if NirklarsCastNotice == nil or NirklarsCastNotice == 0 then
			UIErrorsFrame:AddMessage(message, 0.0, 1.0, 0.0, 3)
		end
	--end
end

--Toggle castnotice
SLASH_NIRKNOTICE1, SLASH_NIRKNOTICE2 = "/nirknotice", "/castingfeedback"
function SlashCmdList.NIRKNOTICE(msg, editbox)
	local status
	if NirklarsCastNotice == nil or NirklarsCastNotice == 0 then
		NirklarsCastNotice = 1
	else
		NirklarsCastNotice = 0
	end
	
	if NirklarsCastNotice == 1 then
		status = "Disabled"
	else
		status = "Enabled"
	end
	Print("Casting message for mouseover casting status: "..tostring(status))
end

--Save warning channel
SLASH_WARNINGCHANNEL1, SLASH_WARNINGCHANNEL2 = "/warnc", "/warningchannel"
function SlashCmdList.WARNINGCHANNEL(msg, editbox)
	if tostring(msg) == "" then
		Print("Warning broadcast channel is currently: "..tostring(NirklarsBindingsWarningChannel))
	else
		NirklarsBindingsWarningChannel = tostring(msg)
		Print("Warning broadcast channel was set to: "..tostring(NirklarsBindingsWarningChannel))
	end
	
end

--Toggle rejuvenation overwrite
SLASH_REJUVOVER1, SLASH_REJUVOVER2 = "/rejuvoverwrite", "/rejuv"
function SlashCmdList.REJUVOVER(msg, editbox)
	local status
	if NirklarsBindingsRejuvOverwrite == nil or NirklarsBindingsRejuvOverwrite == 0 then
		NirklarsBindingsRejuvOverwrite = 1
	elseif NirklarsBindingsRejuvOverwrite == 1 then
		NirklarsBindingsRejuvOverwrite = 2
	else
		NirklarsBindingsRejuvOverwrite = 0
	end
	
	if NirklarsBindingsRejuvOverwrite == 1 then
		status = "Enabled"
	elseif NirklarsBindingsRejuvOverwrite == 2 then
		status = "Swiftmend"
	else
		status = "Disabled"
	end
	Print("Rejuvenation overwrite protection for mouseovercasting: "..tostring(status))
end

--check that a value is a number
function TypeCheck(number)
	number = tonumber(number)
	if type(number) ~= "number" then
		return false
	else
		return true
	end
end

function AutoTarget()
	if GetUnitName("target")==nil then 
		TargetNearestEnemy() 
	end
end

--Automatically target nearest hostile target if no current target, add "/att" at the start of your macro
SLASH_AUTOTARGET1, SLASH_AUTOTARGET2 = "/att", "/autotarget"
function SlashCmdList.AUTOTARGET(msg, editbox)
	AutoTarget()
end

function AutoTarget()
	if GetUnitName("target")==nil then 
		TargetNearestEnemy() 
	end
end

--Automatically self cast spell on self if no current friendly target (useful to work with clique which doesnt allow built in autoselfcast)
SLASH_AUTOSELFCAST1, SLASH_AUTOSELFCAST2 = "/asc", "/autoselfcast"
function SlashCmdList.AUTOSELFCAST(msg, editbox)
	local func = loadstring(msg)
	if UnitIsFriend("player", "target") then 
		--CastSpellByName(msg) 
		NirkMouseoverCast(msg)
	else
		CastSpellByName(msg, 1)
	end
end

function NirkAutoSelfCast(msg)
	CancelForm()
	if UnitIsFriend("player", "target") then 
		--CastSpellByName(msg) 
		NirkMouseoverCast(msg)
	else
		CastSpellByName(msg, 1)
	end
end

--Use action bar if not active /useful for auto attacking mobs "/usa 21" will use ability in actionbar no 21
SLASH_USEACTIONBAR1, SLASH_USEACTIONBAR2 = "/usa", "/useactionbar"
function SlashCmdList.USEACTIONBAR(msg, editbox)
	local func = loadstring(msg)
	if not IsCurrentAction(tonumber(msg)) then 
		UseAction(tonumber(msg))
	end
end

--Use action bar if not active and auto attack (combines both of the above)
SLASH_USEACTIONBARATTACK1, SLASH_USEACTIONBARATTACK2 = "/usat", "/useactionbarattack"
function SlashCmdList.USEACTIONBARATTACK(msg, editbox)
	local func = loadstring(msg)
	if GetUnitName("target")==nil then 
		TargetNearestEnemy() 
	end
	if not IsCurrentAction(tonumber(msg)) then 
		UseAction(tonumber(msg))
	end
end

--Mouseovercast for other spells
SLASH_MOUSEOVERCAST1, SLASH_MOUSEOVERCAST2 = "/mc", "/mouseovercast"
function SlashCmdList.MOUSEOVERCAST(msg, editbox)
	NirkMouseoverCast(msg)
end

--Mouseovercast with warning
SLASH_MOUSEOVERCASTWARNING1, SLASH_MOUSEOVERCASTWARNING2 = "/mcw", "/mouseovercastwarn"
function SlashCmdList.MOUSEOVERCASTWARNING(msg, editbox)
	NirkMouseoverCastWarning(msg)
end

--Cancel shapeshift
SLASH_CANCELFORM1, SLASH_CANCELFORM2 = "/ccf", "/cancelform"
function SlashCmdList.CANCELFORM(msg, editbox)
	CancelForm()
end

function CancelForm()
	for i=1, GetNumShapeshiftForms() do
		_, name, active = GetShapeshiftFormInfo(i)
		if( active ~= nil ) then 
			CastShapeshiftForm(i) 
			break
		end 
	end 
end

function DruidCurrentForm()
	local form = none
	for i=1,4 do
		local _,_,form=GetShapeshiftFormInfo(i)
		if form~=nil then 
			return i 
		end
	end
	return 0
end

-- Use ability enrage, use again to cancel the buff
SLASH_ENRAGE1, SLASH_ENRAGE2 = "/enrage", "/druidenrage"
function SlashCmdList.ENRAGE(msg, editbox)
	DruidEnrageCancel()
end

function DruidEnrageCancel()
	local i=0 
	while not (GetPlayerBuff(i) == -1) do 
		if(strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),"Ability_Druid_Enrage"))then 
			CancelPlayerBuff(GetPlayerBuff(i)) 
		end 
		i = i + 1; 
	end
	CastSpellByName("Enrage")
end

function DruidBarkskinCancel()
	local i=0 
	while not (GetPlayerBuff(i) == -1) do 
		if(strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),"Spell_Nature_StoneClawTotem"))then 
			CancelPlayerBuff(GetPlayerBuff(i)) 
		end 
		i = i + 1; 
	end
	CastSpellByName("Barkskin")
end

function DruidFrenziedRegenCancel()
	local i=0 
	while not (GetPlayerBuff(i) == -1) do 
		if(strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),"Ability_BullRush"))then 
			CancelPlayerBuff(GetPlayerBuff(i)) 
		end 
		i = i + 1; 
	end
	CastSpellByName("Frenzied Regeneration")
end

-- Use ability enrage, use again to cancel the buff
SLASH_TIGERF1, SLASH_TIGERF2 = "/tigerf", "/tigersfury"
function SlashCmdList.TIGERF(msg, editbox)
	TigersFurySpam()
end

function TigersFurySpam()
	--AutoTarget()
	if IsBuffActiveByName("Ability_Mount_JungleTiger") then 
		CastSpellByName("Ravage") 
	else 
		CastSpellByName("Tiger's Fury") 
	end
end

-- Enter cat form and stealth
SLASH_CATFORMSTEALTH1, SLASH_CATFORMSTEALTH2 = "/catform", "/catform"
function SlashCmdList.CATFORMSTEALTH(msg, editbox)
	DruidCatFormStealth()
end

function DruidCatFormStealth()
	if IsBuffActiveByName("Ability_Druid_CatForm") then --is cat form active
		if IsBuffActiveByName("Ability_Ambush") then -- is prowl active
			--do nothing
		else
			CastSpellByName("Prowl")
		end
	else
		if IsBuffActiveByName("Ability_Racial_BearForm") then
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Cat Form")
		end
	end
end

function DruidCatFormSpecial()
	if IsBuffActiveByName("Ability_Druid_CatForm") then --is cat form active
		CastSpellByName("Prowl")
	else
		if IsBuffActiveByName("Ability_Racial_BearForm") then
			AutoTarget()
			CastSpellByName("Growl")
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Cat Form")
		end
	end
end

function IfBear()
	if IsBuffActiveByName("Ability_Racial_BearForm") then 
		return true
	else
		return false
	end
end

function IfCatOrBear()
	if IsBuffActiveByName("Ability_Druid_CatForm") then 
		return true
	elseif IsBuffActiveByName("Ability_Racial_BearForm") then
		return true
	else
		return false
	end
end

function IfCat()
	if IsBuffActiveByName("Ability_Druid_CatForm") then 
		return true
	else
		return false
	end
end

function IfTravel()
	if IsBuffActiveByName("Ability_Druid_TravelForm") then 
		return true
	else
		return false
	end
end

function IfAqua()
	if IsBuffActiveByName("Ability_Druid_AquaticForm") then 
		return true
	else
		return false
	end
end

function WarlockDotRotation(a,b,c,d)
	if not IsDebuffActiveByName("Spell_Fire_Immolation") then
		CastSpellByName("Immolate(Rank "..a..")") 
	elseif not IsDebuffActiveByName("Spell_Shadow_AbominationExplosion") then
		CastSpellByName("Corruption(Rank "..b..")") 
	elseif not IsDebuffActiveByName("Spell_Shadow_CurseOfSargeras") then
		CastSpellByName("Curse of Agony(Rank "..c..")")
	elseif not IsDebuffActiveByName("Spell_Shadow_Requiem") then
		CastSpellByName("Siphon Life(Rank "..d..")")
	end
end 

-- FaerieFire Any form
SLASH_FAERIEFIREANY1, SLASH_FAERIEFIREANY2 = "/faeriefireany", "/faeriefire"
function SlashCmdList.FAERIEFIREANY(msg, editbox)
	FaerieFireAny()
end

function FaerieFireAny()
	if IsBuffActiveByName("Ability_Racial_BearForm") or IsBuffActiveByName("Ability_Druid_CatForm") then --is bear or cat form active
		AutoTarget()
		if UnitLevel("player") >= 54 then
			CastSpellByName("Faerie Fire (Feral)(Rank 4)")
		elseif UnitLevel("player") >= 42 then
			CastSpellByName("Faerie Fire (Feral)(Rank 3)")
		elseif UnitLevel("player") >= 30 then
			CastSpellByName("Faerie Fire (Feral)(Rank 2)")
		else
			CastSpellByName("Faerie Fire (Feral)(Rank 1)")
		end
	else
		if IsDebuffActiveByNameTarget("Spell_Nature_FaerieFire") then
			PrintWarning("FaerieFire is already active on "..CurrentTargetName().."!")
		else
			if UnitLevel("player") >= 54 then
				CastSpellByName("Faerie Fire(Rank 4)")
			elseif UnitLevel("player") >= 42 then
				CastSpellByName("Faerie Fire(Rank 3)")
			elseif UnitLevel("player") >= 30 then
				CastSpellByName("Faerie Fire(Rank 2)")
			else
				CastSpellByName("Faerie Fire(Rank 1)")
			end
		end
	end
end

-- Enter bear form and charge
SLASH_BEARFORMCHARGE1, SLASH_BEARFORMCHARGE2 = "/bearf", "/bearform"
function SlashCmdList.BEARFORMCHARGE(msg, editbox)
	DruidBearFormCharge()
end


function DruidBearFormCharge()
	if IsBuffActiveByName("Ability_Racial_BearForm") then --is bear form active
		AutoTarget()
		CastSpellByName("Feral Charge")
	else
		if IsBuffActiveByName("Ability_Druid_CatForm") then
			CastSpellByName("Cat Form")
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		end
	end
end

-- Enter bear form and bash
SLASH_BEARFORMBASH1, SLASH_BEARFORMBASH2 = "/bearfb", "/bearformb"
function SlashCmdList.BEARFORMBASH(msg, editbox)
	DruidBearFormBash()
end


function DruidBearFormBash()
	if IsBuffActiveByName("Ability_Racial_BearForm") then --is bear form active
		AutoTarget()
		CastSpellByName("Bash")
	else
		if IsBuffActiveByName("Ability_Druid_CatForm") then
			CastSpellByName("Cat Form")
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		end
	end
end

function DruidBearFormSpecial()
	if IsBuffActiveByName("Ability_Racial_BearForm") then --is bear form active
		AutoTarget()
		CastSpellByName("Bash")
	else
		if IsBuffActiveByName("Ability_Druid_CatForm") then
			TigersFurySpam()
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		end
	end
end

-- Enter travel form
--SLASH_TRAVELFORM1, SLASH_TRAVELFORM2 = "/travelf", "/travelform"
--function SlashCmdList.TRAVELFORM(msg, editbox)
--	DruidTravelForm()
--end

function DruidTravelForm()
	if IsBuffActiveByName("Ability_Druid_TravelForm") then --is travel form active
	
	else
		if IsBuffActiveByName("Ability_Druid_CatForm") then
			CastSpellByName("Cat Form")
		elseif IsBuffActiveByName("Ability_Racial_BearForm") then
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		elseif IsBuffActiveByName("Ability_Druid_AquaticForm") then
			CastSpellByName("Aquatic Form")
		else
			CastSpellByName("Travel Form")
		end
	end
end

-- Enter aquatic form
SLASH_AQUATICFORM1, SLASH_AQUATICFORM2 = "/aquaf", "/aquaticform"
function SlashCmdList.TRAVELFORM(msg, editbox)
	DruidAquaticForm()
end

function DruidAquaticForm()
	if IsBuffActiveByName("Ability_Druid_AquaticForm") then --is aquatic form active
	
	else
		if IsBuffActiveByName("Ability_Druid_CatForm") then
			CastSpellByName("Cat Form")
		elseif IsBuffActiveByName("Ability_Racial_BearForm") then
			CastSpellByName("Bear Form")
			CastSpellByName("Dire Bear Form")
		elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
			CastSpellByName("Travel Form")
		else
			CastSpellByName("Aquatic Form")
		end
	end
end

-- Omen of Clarity / Swiftmend / Enrage / Track Humanoids - combo
SLASH_OMENTRACKCOMBO1, SLASH_OMENTRACKCOMBO2 = "/omencombo", "/omentrackcombo"
function SlashCmdList.OMENTRACKCOMBO(msg, editbox)
	OmenTrackCombo()
end

function OmenTrackCombo()
	if IsBuffActiveByName("Ability_Druid_CatForm") then
		CastSpellByName("Track Humanoids")
	elseif IsBuffActiveByName("Ability_Racial_BearForm") then
		DruidEnrageCancel()
	elseif IsBuffActiveByName("Ability_Druid_TravelForm") then
		--do nothing
	else
		CastSpellByName("Omen Of Clarity")
		--NirkMouseoverCast("Swiftmend")
	end
end

-- Lists all buffs on current target
SLASH_BUFFS1 = "/buffs"
function SlashCmdList.BUFFS(msg, editbox)
	for i=1,40 do 
		if UnitBuff("target",i) then 
			DEFAULT_CHAT_FRAME:AddMessage(tostring(i.."="..UnitBuff("target",i)),0.4,1,1) 
		end 
	end
end

-- Lists all buffs on current target
SLASH_DEBUFFS1 = "/debuffs"
function SlashCmdList.DEBUFFS(msg, editbox)
	for i=1,40 do 
		if UnitDebuff("target",i) then 
			DEFAULT_CHAT_FRAME:AddMessage(tostring(i.."="..UnitDebuff("target",i)),0.4,1,1) 
		end 
	end
end

function IsDebuffActiveByName(buffname)
	local i=0 
	for i=1,40 do 
		if(strfind(tostring(UnitDebuff("target",i)),buffname))then 
			return true
		end 
	end
	return false
end

--Cancel buff by interface name
SLASH_CANCELBUFF1, SLASH_CANCELBUFF2 = "/cbf", "/cancelbuff"
function SlashCmdList.CANCELBUFF(msg, editbox)
	CancelBuffByName(msg)
end

function CancelBuffByName(buffname)
	local i=0 
	while not (GetPlayerBuff(i) == -1) do 
		if(strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),buffname))then 
			CancelPlayerBuff(GetPlayerBuff(i)) 
		end 
		i = i + 1; 
	end
end

function IsBuffActiveByName(buffname)
	local i=0 
	while not (GetPlayerBuff(i) == -1) do 
		if(strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),buffname))then 
			return true
		end 
		i = i + 1; 
	end
	return false
end

function IsBuffActiveByNameTarget(buffname)
	for i=1,40 do 
		if(strfind(tostring(UnitBuff("target",i)),buffname))then 
			return true
		end 
	end
	return false
end

function IsDebuffActiveByNameTarget(buffname)
	for i=1,40 do 
		if(strfind(tostring(UnitDebuff("target",i)),buffname))then 
			return true
		end 
	end
	return false
end

SLASH_BUFFCHECK1, SLASH_BUFFCHECK2 = "/buffcheck", "/check"
function SlashCmdList.BUFFCHECK(msg, editbox)
	if msg == "" then
		DEFAULT_CHAT_FRAME:AddMessage("Please specify the name of the buff to look for, example:",0.8,0.3,0.3)
		DEFAULT_CHAT_FRAME:AddMessage("/check Spell_Nature_Regeneration",0.4,1,1)
		DEFAULT_CHAT_FRAME:AddMessage("To list all active buffs of your target use /buffs",0.4,1,1)
	else
		playerlist = MissingBuffCheck(msg)
		DEFAULT_CHAT_FRAME:AddMessage("Checking for buff: "..msg,0.4,1,1) 
		DEFAULT_CHAT_FRAME:AddMessage("Unbuffed players: "..playerlist,0.4,1,1) 
	end
end

SLASH_MOTWCHECK1, SLASH_MOTWCHECK2 = "/motw", "/motwcheck"
function SlashCmdList.MOTWCHECK(msg, editbox)
	BuffCheck("Spell_Nature_Regeneration", msg)
end

function ChatToPartyOrRaid(msg)
	if GetNumRaidMembers() > 0 then
		SendChatMessage(msg,"RAID", nil)
	else
		SendChatMessage(msg,"PARTY", nil)
	end
end

function ChatToChannel(msg, channel)
	if channel == "SAY" or channel == "RAID" or channel == "PARTY" or channel == "GUILD" or channel == "OFFICER" or channel == "YELL" then
		SendChatMessage(tostring(msg),channel, nil)
	else
		DEFAULT_CHAT_FRAME:AddMessage("Invalid channel, use SAY, RAID, PARTY, GUILD, OFFICER or YELL",0.4,1,1)
	end
end

function BuffCheck(buffname,msg)
	local playerlist = MissingBuffCheck(buffname)
	local output
	if playerlist == "" then
		output = "Mark of the Wild - All players are buffed!"
	else
		output = "Mark of the Wild - Unbuffed players: "..playerlist
	end
	
	if msg == "" then
		DEFAULT_CHAT_FRAME:AddMessage(output,0.4,1,1) 
	else
		--ChatToPartyOrRaid(output..playerlist)
	end
end

function MissingBuffCheck(spellname)
	--GetNumRaidMembers()
	
	local playerlist = ""

	--is it a raid? else check party
	if GetNumRaidMembers() > 0 then
		GetNumPartyOrRaidMembers = GetNumRaidMembers()
		PartyOrRaid = "raid"
	else
		GetNumPartyOrRaidMembers = GetNumPartyMembers()
		PartyOrRaid = "party"
	end
	
	--check each party of raid member
	for i=1, GetNumPartyOrRaidMembers do
		found = false
		for j=1,40 do
			if (strfind(tostring(UnitBuff(PartyOrRaid..i,j)),spellname)) then
				found = true
			end 
		end
		
		if found then
			--Print(tostring(i.."="..UnitBuff("party"..i,i)))
		else 
			playerlist = tostring(UnitName(PartyOrRaid..i))..","..playerlist
		end
		
		--info = GetRaidRosterInfo(i)
	end
	
	return playerlist
	
	--Print("Checking for buff: "..spellname)
	--Print("Unbuffed players: "..playerlist)
	
end

function NirkMouseoverThornsMaxRank()
	NirkMouseoverCast(ThornsMaxRank(NirkMouseoverLevel()))
end

function NirkMouseoverMarkOfTheWildMaxRank()
	NirkMouseoverCast(MarkOfTheWildMaxRank(NirkMouseoverLevel()))
end

--Mark all nearby with mark of the wild
SLASH_MOTWSPAM1, SLASH_MOTWSPAM2 = "/motwbuff", "/motwspam"
function SlashCmdList.MOTWSPAM(msg, editbox)
	MarkOfTheWildSpam()
end

function MarkOfTheWildSpam()
	if not UnitExists("target") then
		TargetNearestFriend()
	end
	if UnitIsPlayer("target") then
		if UnitInRange("target") then
			if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
				TargetNearestFriend()
			else
				CastSpellByName(MarkOfTheWildMaxRank(UnitLevel("target")))
			end
		else
			TargetNearestFriend()
		end
	else
		TargetNearestFriend()
	end
end

function MarkOfTheWildMaxRank(unitID)
	if not TypeCheck(unitID) then
		unitID = 60
	end
	--[[
	if not unitID then
		if not UnitExists("target") then
			unitID = "player"
		else
			unitID = "target"
		end
	end
	
	if UnitLevel(unitID) > 50 then
		return "Mark of the Wild(Rank 7)"
	elseif UnitLevel(unitID) > 40 then
		return "Mark of the Wild(Rank 6)"
	elseif UnitLevel(unitID) > 30 then
		return "Mark of the Wild(Rank 5)"
	elseif UnitLevel(unitID) > 20 then
		return "Mark of the Wild(Rank 4)"
	elseif UnitLevel(unitID) > 10 then
		return "Mark of the Wild(Rank 3)"
	elseif UnitLevel(unitID) > 5 then
		return "Mark of the Wild(Rank 2)"
	elseif UnitLevel(unitID) >= 1 then
		return "Mark of the Wild(Rank 1)"
	else
		return "Mark of the Wild(Rank 7)"
	end
	--]]
	if unitID > 50 then
		return "Mark of the Wild(Rank 7)"
	elseif unitID > 40 then
		return "Mark of the Wild(Rank 6)"
	elseif unitID > 30 then
		return "Mark of the Wild(Rank 5)"
	elseif unitID > 20 then
		return "Mark of the Wild(Rank 4)"
	elseif unitID > 10 then
		return "Mark of the Wild(Rank 3)"
	elseif unitID > 5 then
		return "Mark of the Wild(Rank 2)"
	elseif unitID >= 1 then
		return "Mark of the Wild(Rank 1)"
	else
		return "Mark of the Wild(Rank 7)"
	end
end

--Mark all nearby with thorns
SLASH_THORNSSPAM1, SLASH_THORNSSPAM2 = "/thornsbuff", "/thornsspam"
function SlashCmdList.THORNSSPAM(msg, editbox)
	ThornsSpam()
end

function ThornsSpam()
		if not UnitExists("target") then
			TargetNearestFriend()
		end
		if UnitIsPlayer("target") then
			if UnitInRange("target") then
				if IsBuffActiveByNameTarget("Spell_Nature_Thorns") then
					TargetNearestFriend()
				else
					CastSpellByName(ThornsMaxRank(UnitLevel("target")))
				end
			else
				TargetNearestFriend()
			end
		else
			TargetNearestFriend()
		end
end

function Eldsten2()
	TargetByName("Eldsten")
	DidNothing = true
	
	if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
	else
		DidNothing = false
		CastSpellByName("Mark of the Wild(Rank 5)")
	end
	
	TargetByName("Klathgak")

	if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
	else
		DidNothing = false
		CastSpellByName("Mark of the Wild(Rank 5)")
	end
end


function Eldsten()
	--if UnitName("target") == "Eldsten" or UnitName("target")  == "Klathgak" then
	TargetByName("Eldsten")
	
	DidNothing = true
	BuffSpamEldsten()

	if DidNothing == true then
		--TargetNearestFriend()
		TargetByName("Klathgak")
		BuffSpamEldsten()
	end		
	TargetNearestFriend()
end
	


function BuffSpamEldsten()
	--is motw active?
	if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
	else
		DidNothing = false
		CastSpellByName("Mark of the Wild(Rank 6)")
	end
	
	--is thorns active?
	if IsBuffActiveByNameTarget("Spell_Nature_Thorns") then
	else
		DidNothing = false
		CastSpellByName("Thorns(Rank 5)")
	end

	--is rejuv active?
	if IsBuffActiveByNameTarget("Spell_Nature_Rejuvenation") then
	else
		DidNothing = false
		CastSpellByName("Rejuvenation(Rank 8)")
	end
	
	--is regrowth active?
	if IsBuffActiveByNameTarget("Spell_Nature_ResistNature") then
	else
		if UnitHealth("Target") < UnitHealthMax("Target") then
			DidNothing = false
			CastSpellByName("Regrowth(Rank 7)")
		end
	end
end

function DruidBuffTarget()
	local NoTarget = 0
	local TargetUnitLevel = UnitLevel("target")
	
	if GetUnitName("target")==nil then 
		NoTarget = 1
	end
	
	if UnitIsEnemy("target","player") then
		NoTarget = 1
		TargetUnitLevel = UnitLevel("player")
	end
	
	if NoTarget == 1 then
		if not IsBuffActiveByName("Spell_Nature_Regeneration") then
			CastSpellByName(MarkOfTheWildMaxRank(TargetUnitLevel),1)
		end
		
		if not IsBuffActiveByName("Spell_Nature_Thorns") then
			CastSpellByName(ThornsMaxRank(TargetUnitLevel),1)
		end
	else
		if not IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
			CastSpellByName(MarkOfTheWildMaxRank(TargetUnitLevel))
		end
		
		if not IsBuffActiveByNameTarget("Spell_Nature_Thorns") then
			CastSpellByName(ThornsMaxRank(TargetUnitLevel))
		end
	end
	
	if not IsBuffActiveByName("Spell_Nature_CrystalBall") then
		CastSpellByName("Omen of Clarity")
	end
end


function ThornsMaxRank(unitID)
	if not TypeCheck(unitID) then
		unitID = 60
	end
	--[[
	if not unitID then
		if not UnitExists("target") then
			unitID = "player"
		else
			unitID = "target"
		end
	end
	if UnitLevel(unitID) > 50 then
		return "Thorns(Rank 6)"
	elseif UnitLevel(unitID) > 40 then
		return "Thorns(Rank 5)"
	elseif UnitLevel(unitID) > 30 then
		return "Thorns(Rank 4)"
	elseif UnitLevel(unitID) > 20 then
		return "Thorns(Rank 3)"
	elseif UnitLevel(unitID) > 10 then
		return "Thorns(Rank 2)"
	elseif UnitLevel(unitID) >= 1 then
		return "Thorns(Rank 1)"
	else
		return "Thorns(Rank 6)"
	end
	--]]
	if unitID > 50 then
		return "Thorns(Rank 6)"
	elseif unitID > 40 then
		return "Thorns(Rank 5)"
	elseif unitID > 30 then
		return "Thorns(Rank 4)"
	elseif unitID > 20 then
		return "Thorns(Rank 3)"
	elseif unitID > 10 then
		return "Thorns(Rank 2)"
	elseif unitID >= 1 then
		return "Thorns(Rank 1)"
	else
		return "Thorns(Rank 6)"
	end
end

--Use item in bags by name
SLASH_USE1, SLASH_USE2 = "/use", "/useitem"
function SlashCmdList.USE(msg, editbox)
	UseItemByName(msg)
end

function UseItemByName(item)
	local bag,slot = FindItem(item);
	if ( not bag ) then return; end;
	if ( slot ) then
		UseContainerItem(bag,slot); -- use, equip item in bag
		return bag, slot;
	else
		UseInventoryItem(bag); -- unequip from body
		return bag;
	end
end

function use(bag, slot)
	local b,s=tonumber(bag), tonumber(slot);
	if ( b ) then
		if ( s ) then
			UseContainerItem(bag,slot); -- use, equip item in bag
		else
			UseInventoryItem(bag); -- unequip from body
		end
	else
		UseItemByName(bag);
	end
end

function FindItem(item)
	if ( not item ) then return; end
	item = string.lower(ItemLinkToName(item));
	local link;
	for i = 1,23 do
		link = GetInventoryItemLink("player",i);
		if ( link ) then
			if ( item == string.lower(ItemLinkToName(link)) )then
				return i, nil, GetInventoryItemTexture('player', i), GetInventoryItemCount('player', i);
			end
		end
	end
	local count, bag, slot, texture;
	local totalcount = 0;
	for i = 0,NUM_BAG_FRAMES do
		for j = 1,MAX_CONTAINER_ITEMS do
			link = GetContainerItemLink(i,j);
			if ( link ) then
				if ( item == string.lower(ItemLinkToName(link))) then
					bag, slot = i, j;
					texture, count = GetContainerItemInfo(i,j);
					totalcount = totalcount + count;
				end
			end
		end
	end
	return bag, slot, texture, totalcount;
end

function ItemLinkToName(link)
	return gsub(link,"^.*%[(.*)%].*$","%1");
end

-- TESTING DOESNT WORK
function SendChatCommand(cmd)
    local editbox=ChatEdit_ChooseBoxForSend(DEFAULT_CHAT_FRAME);--  Get an editbox
    ChatEdit_ActivateChat(editbox);--   Show the editbox
    editbox:SetText(cmd);-- Command goes here
    ChatEdit_OnEnterPressed(editbox);-- Process command and hide (runs ChatEdit_SendText() and ChatEdit_DeactivateChat() respectively)
end

--Mouseover casting	
function NirkMouseoverName()
	--SpellStopCasting() --- abort previous spell if already casting
	if UnitExists("mouseover") then
		if UnitIsUnit("target", "mouseover") then
			return UnitName("target")
		else
			return UnitName("mouseover")
		end
	end
	if GetMouseFocus().unit then
		if UnitIsUnit("target", GetMouseFocus().unit) then
			return UnitName("target")
		else
			return UnitName(GetMouseFocus().unit)
		end
	else 
		return UnitName("target")
	end
end

function NirkMouseoverLevel()
	local myUnit = NirkMouseoverName()
	if myUnit then
		TargetByName(myUnit, true)
			retVal = UnitLevel("target")
		TargetLastTarget()
	end
	return retVal
end

function NMC(msg)
	NirkMouseoverCast(msg)
end

--Mouseover casting	
function NirkMouseoverCast(msg)
	--SpellStopCasting() --- abort previous spell if already casting
	local func = loadstring(msg)
	if UnitExists("mouseover") then
		if UnitIsUnit("target", "mouseover") then
			if func then
				func()
			else
				--CastNotice(msg,UnitName("target"))
				CastSpellByNameRejuvCheck(msg)
				--CastSpellByName(msg)
				--CastSpellByNameRangeCheckPrint(msg,"target")
				--CastNotice(msg,UnitName("target"),true)
				--Print("1")
			end
			return
		else
			TargetUnit("mouseover")
			if func then
				func()
			else
				--CastNotice(msg,UnitName("target"))
				CastSpellByNameRejuvCheck(msg)
				--CastSpellByName(msg)
				--CastSpellByNameRangeCheckPrint(msg,"target")
				--CastNotice(msg,UnitName("target"),true)
				--Print("2")
			end
			TargetLastTarget()
			return
		end
	end
	if GetMouseFocus().unit then
		if UnitIsUnit("target", GetMouseFocus().unit) then
			if func then
				func()
			else
				--CastNotice(msg,UnitName("target"))
				CastSpellByNameRejuvCheck(msg)
				--CastSpellByNameRangeCheckPrint(msg,GetMouseFocus().unit)
				--CastSpellByName(msg)
				--CastNotice(msg,UnitName("target"),true)
				--Print("3")
			end
		else
			TargetUnit(GetMouseFocus().unit)
			if func then
				func()
			else
				--CastNotice(msg,UnitName("target"))
				CastSpellByNameRejuvCheck(msg)
				--CastSpellByNameRangeCheckPrint(msg,GetMouseFocus().unit)
				--CastSpellByName(msg)
				--CastNotice(msg,UnitName("target"),true)
				--Print("4")
			end
			TargetLastTarget()
		end
	else 
		if func then
			func()
		else
			
			--CastNotice(msg,UnitName("target"))
			--CastSpellByNameRejuvCheck(msg)
			CTRaidCheckCast(msg)
			--CastSpellByNameRangeCheckPrint(msg,GetMouseFocus().unit)
			--CM:Cast(msg)
			--CastSpellByName(msg)
			--CastNotice(msg,UnitName("target"),true)
			--Print("5")
			
		end
	end	
end

function CurrentTargetName()
	if UnitName("target") == nil then
		return UnitName("player")
	else
		return UnitName("target")
	end
end

function CastSpellByNameRejuvCheck(msg)
	if strfind(msg,"Rejuvenation") then
		--if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
		if IsBuffActiveByNameTarget("Spell_Nature_Rejuvenation") then
			if NirklarsBindingsRejuvOverwrite == 1 then
				PrintWarning("Rejuvenation is already active on "..CurrentTargetName().."!")
			elseif NirklarsBindingsRejuvOverwrite == 2 then
				CTRaidCheckCast("Swiftmend")
				CastNotice("Swiftmend",CurrentTargetName())
			else
				CTRaidCheckCast(msg)
				CastNotice(msg,CurrentTargetName())
			end
		elseif UnitIsDeadOrGhost("target") then
			PrintWarning(CurrentTargetName().." is dead!")
		else
			if not UnitInRange("target") then
				PrintWarning(CurrentTargetName().." is out of range! Get closer!")
			end
			CTRaidCheckCast(msg)
			CastNotice(msg,CurrentTargetName())
			--CastSpellByName(msg)
		end
	else
		--CastWarningWhisper(msg)
		--CastWarningChannel(msg)
		--CastSpellByName(msg)
		CTRaidCheckCast(msg)
		CastNotice(msg,CurrentTargetName())
	end
	
end

function UnitInRange(unitID)
	if CheckInteractDistance(unitID, 4) then
		return true
	else
		return false
	end
end

--Healing Touch Nature's Grace Spam
function NaturesGraceAuto()
	local i=0 
	local m=0
	while not (GetPlayerBuff(i)==-1) do 
		if (strfind(GetPlayerBuffTexture(GetPlayerBuff(i)),"Spell_Nature_NaturesBlessing")) then
			m=1 
		end 
		i=i+1 
	end 

	if m==0 then 
		NirkMouseoverCast("Healing Touch(Rank 2)") 
	else 
		NirkMouseoverCast("Healing Touch(Rank 3)") 
	end

end

function CTRaidCheckCast(spell)
	--CT_RA_EmergencyFrameFrame1ClickFrame
	--CT_RA_EmergencyFrameFrame2ClickFrame
	if strfind(GetMouseFocus():GetName(),"CT_RA_EmergencyFrameFrame") or strfind(GetMouseFocus():GetName(),"GridLayoutHeader1UnitButton") then
		CM:Cast(spell)
	else
		CastSpellByName(spell)
	end
end

--[[
-- print information 
function CastSpellByNameRangeCheckPrint(msg, unitID)
	if CastSpellByNameRangeCheck(msg, unitID) == true then
		CastNotice(msg,UnitName(unitID), true)
	else
		CastNotice(msg,UnitName(unitID), false)
	end
end

--Check if target is in range and visible --doesnt work in combination with targetlasttarget
function CastSpellByNameRangeCheck(msg, unitID)
	local ue = UnitExists("target") -- We'll need to know if we have a current target at the moment. 
	local result = false
	ClearTarget() -- Get rid of it, either way
	CastSpellByName(msg) -- This gets us into cursor casting mode.
	if UnitIsVisible(unitID) then
		if SpellCanTargetUnit(unitID) then --check if spell can be cast on target
			SpellTargetUnit(unitID) -- This casts PW:F on unitID example raid1 if in a raid
			result = true
		else
			--TargetLastTarget()
			result = false
		end
	else
		--TargetLastTarget()
		result = false
	end
	--if result == false then SpellStopCasting() end
	if ue then
		TargetLastTarget() -- Return target to initial target if it existed before we claered it.
	end
	return result
end
--]]

--Mouseover casting	warning
function NirkMouseoverCastWarning(msg)
	--SpellStopCasting() --- abort previous spell if already casting
	local func = loadstring(msg)
	if UnitExists("mouseover") then
		if UnitIsUnit("target", "mouseover") then
			if func then
				func()
			else
				CastNotice(msg)
				CastSpellWithWarning(msg,UnitName("target"))
			end
			return
		else
			TargetUnit("mouseover")
			if func then
				func()
			else
				CastNotice(msg)
				CastSpellWithWarning(msg,UnitName("target"))
			end
			TargetLastTarget()
			return
		end
	end
	if GetMouseFocus().unit then
		if UnitIsUnit("target", GetMouseFocus().unit) then
			if func then
				func()
			else
				CastNotice(msg)
				CastSpellWithWarning(msg,UnitName("target"))
			end
		else
			TargetUnit(GetMouseFocus().unit)
			if func then
				func()
			else
				CastNotice(msg)
				CastSpellWithWarning(msg,UnitName("target"))
			end
			TargetLastTarget()
		end
	else 
		if func then
			func()
		else
			CastNotice(msg)
			CastSpellWithWarning(msg,UnitName("target"))
		end
	end	
	
end

-- Innervate overwrite prevention
SLASH_INNERVATE1 = "/innervate"
function SlashCmdList.INNERVATE(msg, editbox)
	NirkMouseoverCastWarning("Innervate") 
end

function DotDotDot()
	if GetUnitName("target")==nil then TargetNearestEnemy() end
	
	if IsBuffActiveByName("Spell_Shadow_Twilight") then
		CastSpellByName("Shadow Bolt(Rank 7)")
	end
	if IsDebuffActiveByNameTarget("Spell_Shadow_LifeDrain02") then
	
	else
		if not IsDebuffActiveByNameTarget("Spell_Shadow_Requiem") then
			CastSpellByName("Siphon Life(Rank 2)")
		end
		if not IsDebuffActiveByNameTarget("Spell_Shadow_AbominationExplosion") then
			CastSpellByName("Corruption(Rank 5)")
		end
		if not IsDebuffActiveByNameTarget("Spell_Shadow_CurseOfSargeras") then
			CastSpellByName("Curse of Agony(Rank 4)")
		end
		if not IsDebuffActiveByNameTarget("Spell_Fire_Immolation") then
			CastSpellByName("Immolate(Rank 5)")
		end
		if not IsDebuffActiveByNameTarget("Spell_Shadow_LifeDrain02") then
			if UnitHealth("player")>=UnitHealthMax("player") and UnitMana("player")<UnitManaMax("Player") then
				CastSpellByName("Life Tap(Rank 4)")
			else
				CastSpellByName("Drain Life(Rank 4)")
			end
		end
	end
end

--message
function CastSpellWithWarning(msg)
	--if msg == "Healing Touch(Rank 3)" then
	if msg == "Innervate" then
		--if IsBuffActiveByNameTarget("Spell_Nature_Regeneration") then
		if IsBuffActiveByNameTarget("Spell_Nature_Lightning") then
			PrintWarning("Warning <<INNERVATE>> is already active on "..UnitName("target").." canceling!")
		elseif UnitIsDeadOrGhost("target") then
			PrintWarning(UnitName("target").." is dead!")
		else
			if UnitInRange("target") then
				CastWarningWhisper(msg)
				CastWarningChannel(msg)
			else
				PrintWarning(UnitName("target").." is out of range! Get closer!")
			end
			CTRaidCheckCast(msg)
			--CastSpellByName(msg)
		end
	elseif strfind(msg,"Rebirth") then
		if UnitIsDeadOrGhost("target") then
			if UnitInRange("target") then
				CastWarningWhisper(msg)
				CastWarningChannel(msg)
			else
				PrintWarning(UnitName("target").." is out of range! Get closer!")
			end
			--CastSpellByName(msg)
			CTRaidCheckCast(msg)
		else
			PrintWarning(UnitName("target").." is not dead.")
		end
	else
		CastWarningWhisper(msg)
		CastWarningChannel(msg)
		--CastSpellByName(msg)
		CTRaidCheckCast(msg)
	end
end

function CastWarningWhisper(msg)
	if UnitExists("target") then 
		if not UnitIsUnit("target", "player") then 
			if UnitIsFriend("player", "target") then
				if UnitIsPlayer("target") then
					--SendChatMessage("Casting "..msg.." on "..UnitName("target"),"SAY")
					SendChatMessage("Casting <<"..string.upper(msg)..">> on you!","WHISPER", nil,UnitName("target"))
				end
			end
		end 
	end
end

function CastWarningChannel(msg)
	if UnitExists("target") then 
		if not UnitIsUnit("target", "player") then 
			if UnitIsFriend("player", "target") then
				if UnitIsPlayer("target") then
					local index = GetChannelName(NirklarsBindingsWarningChannel)
					if (index~=nil) then 
						SendChatMessage("Casting <<"..string.upper(msg)..">> on "..UnitName("target"), "CHANNEL", nil, index); 
					end
				end
			end
		end 
	end
end

SLASH_MODECURSE1 = "/modecurse"
function SlashCmdList.MODECURSE(msg, editbox)
	MouseoverDecurse()
end

function maxmin(t)
  local max = -math.huge
  local min = math.huge

  for k,v in pairs( t ) do
    if type(v) == 'number' then
      max = math.max( max, v )
      min = math.min( min, v )
    end
  end

  return max, min
end

-- WORK IN PROGRESS
function TargetLowestHPInRaid()
	
	--Table storing raid HP
	raidHP = {}
	
	--is it a raid? else check party
	if GetNumRaidMembers() > 0 then
		GetNumPartyOrRaidMembers = GetNumRaidMembers()
		PartyOrRaid = "raid"
	else
		GetNumPartyOrRaidMembers = GetNumPartyMembers()
		PartyOrRaid = "party"
	end
	
	--go through each party of raid member
	local prevUnitHealth = 0
	for i=1, GetNumPartyOrRaidMembers do
		currentUnit = PartyOrRaid..i
		--raidHP[tostring(UnitName(myUnit))] = UnitHealthMax(myUnit)-UnitHealth(myUnit)
		--raidHP[i] = UnitHealthMax(myUnit)-UnitHealth(myUnit)
		currentUnitHealth = UnitHealthMax(currentUnit)-UnitHealth(currentUnit)
		if currentUnitHealth > prevUnitHealth then
			UnitLargestDiff = i
		end
		
		Print(i.."  "..prevUnitHealth.."  "..currentUnitHealth)
		
		prevUnitHealth = currentUnitHealth
		
		--info = GetRaidRosterInfo(i)
	end
	
	--Print(UnitLargestDiff)
	
	
	--Print(tostring(math.max(unpack(raidHP))))
	
	--for k, v in pairs( raidHP ) do
	--   Print("player: "..k, " healthdiff: "..v)
	--end
	
	--local player = 0
	--local max_val = 0
	--for k, v in pairs( raidHP ) do
	--   player = player + 1
	--   Print("player: "..k, " healthdiff: "..v)
	--	if v > max_val then
	--		max_val = v
	--		break
	--	end
	--end

	--Print(player.." "..max_val)

end


function MouseoverDecurse()

	SpellStopCasting()
	
	if UnitExists("mouseover") then
		if UnitIsUnit("target", "mouseover") then
			MouseverDecurseChooseSpell()
			return
		else
			TargetUnit("mouseover")
			MouseverDecurseChooseSpell()
			TargetLastTarget()
			return
		end
	end
	if GetMouseFocus().unit then
		if UnitIsUnit("target", GetMouseFocus().unit) then
			MouseverDecurseChooseSpell()
		else
			TargetUnit(GetMouseFocus().unit)
			MouseverDecurseChooseSpell()
			TargetLastTarget()
		end
	else 
		MouseverDecurseChooseSpell()
	end	
end

function MouseoverLookForDebuffType(stringMyType)
	for i=1,40 do 
		DebuffTexture, debuffApplications, debuff_type = UnitDebuff("target", i)
		if tostring(debuff_type) == tostring(stringMyType) then 
			return true
		end
	end
	return false
end

function MouseverDecurseChooseSpell()
	if UnitIsFriend("target","player") then
		if tostring(UnitClass("player")) == "Druid" then
			if MouseoverLookForDebuffType("Poison") then
				CastSpellByName("Abolish Poison")
			elseif MouseoverLookForDebuffType("Curse") then
				CastSpellByName("Remove Curse")
			else
				MouseoverDecurseWarning("Druid: No poison/curse found on "..GetUnitName("target"))
			end
		end
		
		if tostring(UnitClass("player")) == "Priest" then
			if MouseoverLookForDebuffType("Magic") then
				CastSpellByName("Dispel Magic")
			elseif MouseoverLookForDebuffType("Disease") then
				CastSpellByName("Abolish Disease")
			else
				MouseoverDecurseWarning("Priest: No magic/curse found on "..GetUnitName("target"))
			end
		end
		
		if tostring(UnitClass("player")) == "Mage" then
			if MouseoverLookForDebuffType("Curse") then
				CastSpellByName("Remove Lesser Curse")
			else
				MouseoverDecurseWarning("Mage: No curses found on "..GetUnitName("target"))
			end
		end
		
		if tostring(UnitClass("player")) == "Shaman" then
			if MouseoverLookForDebuffType("Poison") then
				CastSpellByName("Cure Poison")
			elseif MouseoverLookForDebuffType("Disease") then
				CastSpellByName("Cure Disease")
			else
				MouseoverDecurseWarning("Mage: No poison/disease found on "..GetUnitName("target"))
			end
		end
		
		if tostring(UnitClass("player")) == "Paladin" then
			if MouseoverLookForDebuffType("Poison") then
				CastSpellByName("Cleanse")
			elseif MouseoverLookForDebuffType("Disease") then
				CastSpellByName("Cleanse")
			elseif MouseoverLookForDebuffType("Magic") then
				CastSpellByName("Cleanse")
			else
				MouseoverDecurseWarning("Paladin: No poison/disease/magic found on "..GetUnitName("target"))
			end
		end
	end
end

function MouseoverDecurseWarning(msg)
	if NirklarsCastNotice == nil or NirklarsCastNotice == 0 then
		UIErrorsFrame:AddMessage(tostring(msg), 0.3, 0.3, 1, 3)
	end
end
