Version 1.63
Some keybinds for wow :) when macros are not enough

https://nirklars.wordpress.com/wow/nirklars-keybindings/