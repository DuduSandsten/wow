--requires wowace

function GuildRosterPrint(msg)
	DEFAULT_CHAT_FRAME:AddMessage(tostring(msg),0.4,1,1, 3)
end

function GuildRosterPrintWarning(msg)
	UIErrorsFrame:AddMessage(tostring(msg), 0.4,1,1, 3)
end
	
--list items in inventory
SLASH_BANKINV1, SLASH_BANKINV2, SLASH_BANKINV3 = "/gb", "/guildbank", "/itemlist"
function SlashCmdList.BANKINV(msg, editbox)
	
	-- table formatting
	output = "<style>body{font-family: arial;}</style><body>"
	
	--add name of character
	output = output .. " <b>Inventory of " .. UnitName("player").. "<br>Current Gold: "..math.floor(GetMoney()/100/100).."<br></b>"
	
	--beginning of table
	output = output .. "<b></b><table><tr><td><b>Item</b></td><td><b>Amount</b></td></tr>"
	--output = output .. "<b></b><table><tr><td><b>Item</b></td><td><b>Amount</b></td><td><b>Itemid</b></td></tr>"
	
   --function u(ItemName)
		
		--items = {luaH_set = 10,luaH_get = 24,luaH_present = 48,}
		items = {}
		itemIDs = {}
		
		--check if bank is open
		if GetBagName(5) == nil then 
			--you dont have the bank open
			GuildRosterPrint("WARNING! Bank is not openeded!")
			GuildRosterPrint("WARNING! Or no bags are placed in bank!")
			GuildRosterPrint("WARNING! Make sure you have the bank open!")
			GuildRosterPrintWarning("WARNING! Make sure you have the bank open!")
			PlaySound("igQuestFailed")
		end
			
			--go through bank slots start after 16
			for i=17,100 do 
				
				--skip bag slots between 41 to 46 those are the bags themselves
				if i>40 and i<47 then
				else
					ItemLink=GetContainerItemLink(0,i)
					if (ItemLink) then
						local texture, itemCount, locked, quality, readable, lootable, ItemLink2 = GetContainerItemInfo(0,i)
						local _, _, itemId = string.find(ItemLink,"item:(%d+).+%[(.+)%]")
						local _, _, itemName = string.find(ItemLink, "^.*%[(.*)%].*$")
						
						if itemCount then
							--if item already exist then add count together
							if items[itemName] then
								items[itemName] = items[itemName] + itemCount
							else
								items[itemName] = itemCount
							end
							
							-- todo: add item id with link maybe
							itemIDs[itemName] = itemId
						end
					end
				end
			end
			
			
			--[[
			--get number of bags in bank
			numBags=1 --initial value
			for i=1,11 do
				numBags = numBags + 1
				if GetBagName(i) == nil then 
					break 
				end
			end
			--]]
		
			--get items from bags
			for bag=0,15 do 
				for i=1,GetContainerNumSlots(bag) do 
					ItemLink=GetContainerItemLink(bag,i)
					if (ItemLink) then 
						local texture, itemCount, locked, quality, readable, lootable, ItemLink2 = GetContainerItemInfo(bag,i)
						local _, _, itemId = string.find(ItemLink,"item:(%d+).+%[(.+)%]")
						local _, _, itemName = string.find(ItemLink, "^.*%[(.*)%].*$")
						
						if itemCount then
							--if item already exist then add count together
							if items[itemName] then
								items[itemName] = items[itemName] + itemCount
							else
								items[itemName] = itemCount
							end
							
							-- todo: add item id with link maybe
							itemIDs[itemName] = itemId
						end
					end 
				end 
			end 

	
		

	for name, count in pairsByKeys(items) do
		output = output.."<tr><td><a href=\"https://vanilla-twinhead.twinstar.cz/?item="..itemIDs[name].."\">" .. name .. "</a></td><td>" .. count .. "</td></tr>"
		
		--output = output.."<tr><td>" .. name .. "</td><td>" .. count .. "</td><td>" .. itemIDs[name] .. "</td><td></tr>"
	end
	
	output = output .. "</table></body>"

	--TODO remove square brackets
	
	StaticPopupDialogs["COPYTEXT"] = {
		text = "CharacterInventory - Copy and paste the text below and paste into a text editor, then save as anything.html and open in a browser.",
	  	button1 = "OK",
		
		OnShow = function()
			getglobal(this:GetName().."EditBox"):SetFocus()
			getglobal(this:GetName().."EditBox"):SetPoint("TOP", getglobal(this:GetName().."EditBox"):GetParent(), "TOP", 0, -100);
			getglobal(this:GetName().."EditBox"):SetText(output)
			getglobal(this:GetName().."EditBox"):HighlightText()
		end,
		
	  	timeout = 0,
	  	hasEditBox = true,
	  	whileDead = true,
	  	hideOnEscape = true,
	  	preferredIndex = 3,  -- avoid some UI taint, see http://www.wowace.com/announcements/how-to-avoid-some-ui-taint/
	}
	StaticPopup_Show ("COPYTEXT")
	
end

    function pairsByKeys (t, f)
      local a = {}
      for n in pairs(t) do table.insert(a, n) end
      table.sort(a, f)
      local i = 0      -- iterator variable
      local iter = function ()   -- iterator function
        i = i + 1
        if a[i] == nil then return nil
        else return a[i], t[a[i]]
        end
      end
      return iter
    end

SLASH_GUILDROSTER1, SLASH_GUILDROSTER2 = "/gr", "/guildroster"
function SlashCmdList.GUILDROSTER(msg, editbox)
	numberOfMembers = GetNumGuildMembers(true);
	
	--table formatting
	output = "<style>table{font-family: arial;}</style><table><tr><td><strong>Name</strong></td><td><strong>Rank</strong></td><td><strong>Class</strong></td><td><strong>Level</strong></td><td><strong>Note</strong></td><td><strong>Officer note</strong></td></tr>";
	
	--go through every member in the guild
	for i = 1, numberOfMembers do
		name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName = GetGuildRosterInfo(i);

		output =  output .. "<tr><td>" .. name .. "</td><td>" .. rank .. "</td><td>" .. class .. "</td><td>" .. level .. "</td><td>".. note .. "</td><td>".. officernote .. "</td><td></tr>";
	end
	
	output = output .. "</table>";
	
	--show message box to copy and paste from
	StaticPopupDialogs["COPYTEXT"] = {
		text = "GuildRoster - Copy and paste the text below and paste into a text editor, then save as anything.html and open in a browser.",
	  	button1 = "OK",
		
		OnShow = function()
			getglobal(this:GetName().."EditBox"):SetFocus()
			getglobal(this:GetName().."EditBox"):SetPoint("TOP", getglobal(this:GetName().."EditBox"):GetParent(), "TOP", 0, -100);
			getglobal(this:GetName().."EditBox"):SetText(output)
			getglobal(this:GetName().."EditBox"):HighlightText()
		end,
		
	  	timeout = 0,
	  	hasEditBox = true,
	  	whileDead = true,
	  	hideOnEscape = true,
	  	preferredIndex = 3,  -- avoid some UI taint, see http://www.wowace.com/announcements/how-to-avoid-some-ui-taint/
	}
	StaticPopup_Show ("COPYTEXT")
end
