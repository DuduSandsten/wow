if ARM_AddClassColorByName == nil then
	function ARM_AddClassColorByName(a,b)
		return b
	end
end

function ActionButton_SetTooltip()
	if ( GetCVar("UberTooltips") == "1" ) then
		GameTooltip_SetDefaultAnchor(GameTooltip, this);
	else
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
	end
	
	local slot = ActionButton_GetPagedID(this)
	local text = GetActionText(slot)
	
	bool = false
	if text then
		name = true
		slot2 = 0
		Text = ""
		while name do
			slot2 = slot2 +1
			name,_,body = GetMacroInfo(slot2)
			if (name == text) then
				name = false
				Text = body
			end
		end
		
		if Text == "" then
			name = true
			slot2 = 19
			while name do
				slot2 = slot2 +1
				name,_,body = GetMacroInfo(slot2)
				if (name == text) then
					name = false
					Text = body
				end
			end
		end
		for word in string.gfind(Text, "[^%\n]+") do
			-- SETSPELLTOOLTIP
			if (string.sub(word,1,16) == "/setspelltooltip") then
				name = true
				slot2 = 0
				while name do
					slot2 = slot2 +1
					name = GetSpellName(slot2,"player")
					if name == string.sub(word,18) then
						name = false
					end
				end
				GameTooltip:SetSpell(slot2,"player")
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			if (string.sub(word,1,5) == "/sstt") then
				name = true
				slot2 = 0
				while name do
					slot2 = slot2 +1
					name = GetSpellName(slot2,"player")
					if name == string.sub(word,7) then
						name = false
					end
				end
				GameTooltip:SetSpell(slot2,"player")
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			
			
			-- SETINVNETORYTOOLTIP
			if (string.sub(word,1,20) == "/setinventorytooltip") then
				slots = {head = 1, neck = 2, shoulder = 3, shirt = 4, chest = 5, belt = 6, legs = 7, feet = 8, writ = 9, gloves = 10, finger = 11, finger1 = 11, ring = 11, ring1 = 11, finger2 = 12, ring2 = 12, trinket1 = 13, trinket = 13, trinket2 = 14, back = 15}
				slot2 = slots[string.sub(word,22)] or tonumber(string.sub(word,19))
				GameTooltip:SetInventoryItem("player", slot2)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			if (string.sub(word,1,5) == "/sitt") then
				slots = {head = 1, neck = 2, shoulder = 3, shirt = 4, chest = 5, belt = 6, legs = 7, feet = 8, writ = 9, gloves = 10, finger = 11, finger1 = 11, ring = 11, ring1 = 11, finger2 = 12, ring2 = 12, trinket1 = 13, trinket = 13, trinket2 = 14, back = 15}
				slot2 = slots[string.sub(word,7)] or tonumber(string.sub(word,7))
				GameTooltip:SetInventoryItem("player", slot2)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			
			
			-- ADDTEXTTTOLTIP
			if (string.sub(word,1,15) == "/addtexttooltip") then
				GameTooltip:AddLine(string.sub(word,17),0.8,0.8,1)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			if (string.sub(word,1,5) == "/attt") then
				GameTooltip:AddLine(string.sub(word,7),0.8,0.8,1)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			
			
			-- SETTEXTTOOLTIP
			if (string.sub(word,1,15) == "/settexttooltip") then
				GameTooltip:SetText(string.sub(word,17),1,1,0.5)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			if (string.sub(word,1,5) == "/sttt") then
				GameTooltip:SetText(string.sub(word,7),1,1,0.5)
				this.updateTooltip = TOOLTIP_UPDATE_TIME;
				bool = true
			end
			
			
			-- ADDUNBUFFEDTOOLTIP
			if (string.sub(word,1,19) == "/addunbuffedtooltip") then
				local buff = string.sub(word,21)
				local nobuff = {{},{},{},{},{},{},{},{}}
				if UnitHasBuff == nil then
					GameTooltip:AddLine("\"/addunbuffedtooltip\" requires:",1,0,0)
					GameTooltip:AddLine("\- Anarons Raid Mod",1,0,0)
				else
					for i = 1,40 do
						local target = "raid"..i
						if UnitName(target) then
							if not UnitHasBuff(target,buff,false) then
								_,_,group = GetRaidRosterInfo(i)
								nobuff[group][table.getn(nobuff[group])+1]= UnitName(target)
							end
						end
					end
					for i = 0,3 do
						if not (nobuff[i*2+1][1] == nil and nobuff[i*2+2][1] == nil) then
							GameTooltip:AddDoubleLine("Group"..(i*2+1)..":","Group"..(i*2+2)..":", 1,0.2,0.2, 1,0.2,0.2)
						end
						
						for j = 1,5 do
							if nobuff[i*2+2][j] then
								nobuff[i*2+1][j] = nobuff[i*2+1][j] or " "
							end
							if nobuff[i*2+1][j] then
								nobuff[i*2+2][j] = nobuff[i*2+2][j] or " "
							end
							GameTooltip:AddDoubleLine(nobuff[i*2+1][j] or "",nobuff[i*2+2][j] or "")
						end
					end
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					bool = true
				end
			end
			
			if (string.sub(word,1,6) == "/aubtt") then
				local buff = string.sub(word,8)
				local nobuff = {{},{},{},{},{},{},{},{}}
				if UnitHasBuff == nil then
					GameTooltip:AddLine("\"/aubtt\" requires:",1,0,0)
					GameTooltip:AddLine("\- Anarons Raid Mod",1,0,0)
				else
					for i = 1,40 do
						local target = "raid"..i
						if UnitName(target) then
							if not UnitHasBuff(target,buff,false) then
								_,_,group = GetRaidRosterInfo(i)
								nobuff[group][table.getn(nobuff[group])+1]= UnitName(target)
							end
						end
					end
					for i = 0,3 do
						if not (nobuff[i*2+1][1] == nil and nobuff[i*2+2][1] == nil) then
							GameTooltip:AddDoubleLine("Group"..(i*2+1)..":","Group"..(i*2+2)..":", 1,0.2,0.2, 1,0.2,0.2)
						end
						
						for j = 1,5 do
							if nobuff[i*2+2][j] then
								nobuff[i*2+1][j] = nobuff[i*2+1][j] or " "
							end
							if nobuff[i*2+1][j] then
								nobuff[i*2+2][j] = nobuff[i*2+2][j] or " "
							end
							GameTooltip:AddDoubleLine(nobuff[i*2+1][j] or "",nobuff[i*2+2][j] or "")
						end
					end
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					bool = true
				end
			end
			
		end
	end
	if bool then
		GameTooltip:Show()
		return
	end
	if ( GameTooltip:SetAction(slot) ) then
		this.updateTooltip = TOOLTIP_UPDATE_TIME;
	else
		this.updateTooltip = nil;
	end
end

SlashCmdList["SETTOOLTIP_COMMAND"] = function(Flag)
end
SLASH_SETTOOLTIP_COMMAND1 = "/setspelltooltip";
SLASH_SETTOOLTIP_COMMAND2 = "/setinventorytooltip";
SLASH_SETTOOLTIP_COMMAND3 = "/settexttooltip";

SlashCmdList["STT_COMMAND"] = function(Flag)
end
SLASH_STT_COMMAND1 = "/sstt";
SLASH_STT_COMMAND2 = "/sitt";
SLASH_STT_COMMAND3 = "/sttt";

SlashCmdList["ADDTOTOOLTIP_COMMAND"] = function(Flag)
end
SLASH_ADDTOTOOLTIP_COMMAND1 = "/addtexttooltip";
SLASH_ADDTOTOOLTIP_COMMAND2 = "/addunbuffedtooltip";

SlashCmdList["ATT_COMMAND"] = function(Flag)
end
SLASH_ATT_COMMAND1 = "/attt";
SLASH_ATT_COMMAND2 = "/aubtt";


