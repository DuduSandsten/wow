AutoStanceDance = CreateFrame("Frame")
AutoStanceDance:RegisterEvent("UI_ERROR_MESSAGE")

AutoStanceDanceLastErr = ""
Hook_CastSpell = CastSpell
Hook_CastSpellByName = CastSpellByName
Hook_UseAction = UseAction

-- deDE
AutoStanceDance.wantBattleStance = "Must be in Battle Stance"
AutoStanceDance.wantBattleDefStance = "Must be in Battle Stance, Berserker Stance"
AutoStanceDance.BattleStance = "Battle Stance"
AutoStanceDance.BattleStance = "Battle Stance"
AutoStanceDance.wantBerserkerStance = "Must be in Berserker Stance"
AutoStanceDance.BerserkerStance = "Berserker Stance"
AutoStanceDance.wantDefensiveStance = "Must be in Defensive Stance"
AutoStanceDance.DefensiveStance = "Defensive Stance"

function CastSpell(spellId, spellbookTabNum)
  if AutoStanceDanceLastErr == AutoStanceDance.wantBattleStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBattleDefStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBerserkerStance then
    Hook_CastSpellByName(AutoStanceDance.BerserkerStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantDefensiveStance then
    Hook_CastSpellByName(AutoStanceDance.DefensiveStance)
  end
  AutoStanceDanceLastErr = ""

  Hook_CastSpell(spellId, spellbookTabNum)
end

function CastSpellByName(spellName, onSelf)
  if AutoStanceDanceLastErr == AutoStanceDance.wantBattleStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBattleDefStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBerserkerStance then
    Hook_CastSpellByName(AutoStanceDance.BerserkerStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantDefensiveStance then
    Hook_CastSpellByName(AutoStanceDance.DefensiveStance)
  end
  AutoStanceDanceLastErr = ""

  Hook_CastSpellByName(spellName, onSelf)
end

function UseAction(slot, checkCursor, onSelf)
  if AutoStanceDanceLastErr == AutoStanceDance.wantBattleStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBattleDefStance then
    Hook_CastSpellByName(AutoStanceDance.BattleStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantBerserkerStance then
    Hook_CastSpellByName(AutoStanceDance.BerserkerStance)
  elseif AutoStanceDanceLastErr == AutoStanceDance.wantDefensiveStance then
    Hook_CastSpellByName(AutoStanceDance.DefensiveStance)
  end
  AutoStanceDanceLastErr = ""

  Hook_UseAction(slot, checkCursor, onSelf)
end

AutoStanceDance:SetScript("OnEvent", function()
  AutoStanceDanceLastErr = arg1
end)
