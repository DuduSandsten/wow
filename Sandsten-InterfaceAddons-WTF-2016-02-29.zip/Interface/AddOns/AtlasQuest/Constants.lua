--[[
 More constants soon
]]

--Vesiontext festlegen (als variable)
local VERSION_CORE = "|cffff00003";
local VERSION_INSTANZEN = "20";
local VERSION_REST = "56|r"
ATLASQUEST_VERSION = "Joana's Quest";

--------------DEADMINES/Inst1------------

Inst1Quest4PreQuest = "true"
Inst1Quest5PreQuest = "true"
Inst1Quest6PreQuest = "true"

--------------LBRS/Inst8 ------------

Inst8Quest1PreQuest = "true"
Inst8Quest8FQuest = "true"

Inst8Quest1PreQuest_HORDE = "true"
Inst8Quest8FQuest_HORDE = "true"

--------------UBRS/Inst9 ------------

Inst9Quest3PreQuest = "true"
Inst9Quest4PreQuest = "true"
Inst9Quest5PreQuest = "true"
Inst9Quest6PreQuest = "true"
Inst9Quest7PreQuest = "true"

Inst9Quest3PreQuest_HORDE = "true"
Inst9Quest4PreQuest_HORDE = "true"
Inst9Quest5PreQuest_HORDE = "true"
Inst9Quest6PreQuest_HORDE = "true"
Inst9Quest7FQuest_HORDE = "true"
Inst9Quest8FQuest_HORDE = "true"

--------------DireMaul/Inst10 ------------

Inst10Quest9FQuest = "true"

Inst10Quest9FQuest_HORDE = "true"