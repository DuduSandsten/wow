This addon automatically changes stance depending on which ability you attempt to use.
It does this by reading the UI error text. This means you need to press twice in order to use them

Converted/translated to english version of wow by nirklars 2016-05-08
http://nirklars.wordpress.com/wow

Original by Eric (Shagu) Mauser
http://shaguaddons.ericmauser.de/shagucollection/