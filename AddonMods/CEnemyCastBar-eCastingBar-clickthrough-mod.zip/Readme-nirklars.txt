Modified by Nirklars 2015-09-28
https://nirklars.wordpress.com/wow/addons-modified-old-addons/