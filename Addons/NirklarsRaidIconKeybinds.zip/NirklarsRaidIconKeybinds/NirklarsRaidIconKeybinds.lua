------------------------------
-- NirklarsRaidIconKeybinds --
------------------------------

-- Localisation stuff

BINDING_HEADER_NIRKLARSRAIDICON = "RaidIcon mouseover keybindings";
BINDING_NAME_NIRKLARSRAIDICON0 = "Remove icon";
BINDING_NAME_NIRKLARSRAIDICON1 = "Icon 1 Star";
BINDING_NAME_NIRKLARSRAIDICON2 = "Icon 2 Circle";
BINDING_NAME_NIRKLARSRAIDICON3 = "Icon 3 Diamond";
BINDING_NAME_NIRKLARSRAIDICON4 = "Icon 4 Triangle";
BINDING_NAME_NIRKLARSRAIDICON5 = "Icon 5 Moon";
BINDING_NAME_NIRKLARSRAIDICON6 = "Icon 6 Square";
BINDING_NAME_NIRKLARSRAIDICON7 = "Icon 7 Cross";
BINDING_NAME_NIRKLARSRAIDICON8 = "Icon 8 Skull";

function NirklarsRaidIconSet(keystate,iconnumber)
	if ( keystate == "down" ) then
		--DEFAULT_CHAT_FRAME:AddMessage("Setting Icon "..iconnumber);
		if GetRaidTargetIndex("mouseover") == nil then
			SetRaidTarget("mouseover", iconnumber)
		else
			if GetRaidTargetIndex("mouseover") == iconnumber then
				SetRaidTarget("mouseover", 0)
			else
				SetRaidTarget("mouseover", iconnumber)
			end 
		end
    end
end
