Luna unit frames Clique plugin support (for version 1095 october 2015) updated!
https://github.com/Aviana/LunaUnitFrames

Updated by Nirklars :)
https://nirklars.wordpress.com/wow/