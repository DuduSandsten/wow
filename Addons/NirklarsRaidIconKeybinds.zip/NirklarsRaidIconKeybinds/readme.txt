Version 1
Some keybinds for wow :) when macros are not enough