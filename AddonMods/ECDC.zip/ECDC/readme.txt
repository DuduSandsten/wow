Edits made by Nirklars
http://nirklars.wordpress.com/wow/

CHANGELOG:
2016-02-13
Feature added to enable hiding the anchor
New commands (they all work the same):
/eccshow
/ecctoggle
/ecchide
/ecchide